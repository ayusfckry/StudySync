import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Terminal, Shield, LogIn, UserPlus } from 'lucide-react';
import { signInWithGoogle } from '../firebase';

const Auth: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="min-h-screen bg-terminal-bg flex items-center justify-center p-6 relative overflow-hidden">
      <div className="crt-overlay" />
      <div className="scanline" />

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md terminal-border bg-terminal-bg/80 p-10 space-y-10 z-10"
      >
        <div className="flex flex-col items-center gap-4">
          <Terminal className="w-16 h-16 text-terminal-green" />
          <h1 className="text-4xl font-bold glitch-text" data-text="StudySync">StudySync</h1>
          <p className="text-xs text-terminal-green/60 uppercase tracking-widest">Survivor Network v1.0.4</p>
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs text-terminal-green/60 uppercase">Operator ID</label>
            <input type="text" className="terminal-input" placeholder="SURVIVOR_ID" />
          </div>
          <div className="space-y-2">
            <label className="text-xs text-terminal-green/60 uppercase">Access Code</label>
            <input type="password" className="terminal-input" placeholder="********" />
          </div>

          <button className="terminal-button w-full flex items-center justify-center gap-2">
            {isLogin ? <LogIn className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
            {isLogin ? 'Initiate Link' : 'Register Identity'}
          </button>

          <div className="relative py-4">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-terminal-border"></div></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-terminal-bg px-2 text-terminal-green/40">External Auth</span></div>
          </div>

          <button
            onClick={signInWithGoogle}
            className="terminal-button w-full border-terminal-amber text-terminal-amber hover:bg-terminal-amber hover:text-terminal-bg flex items-center justify-center gap-2"
          >
            <Shield className="w-4 h-4" />
            Google Authentication
          </button>
        </div>

        <div className="text-center">
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-xs text-terminal-green/40 hover:text-terminal-green uppercase transition-colors duration-200"
          >
            {isLogin ? 'New survivor? Register here' : 'Already registered? Login here'}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default Auth;
